from django.contrib import admin
from django.contrib import admin
from.models import customer
# Register your models here.
admin.site.register(customer)

# Register your models here.
