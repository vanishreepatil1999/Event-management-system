from django.shortcuts import render
from.models import customer


# Create your views here.

#def index(request):
 #   return HttpResponse("<H2>Welcome TO Our  Eventmanagement:</h2> <ul> <li> organizer: vanishree patil</li><li> email: vanishreepatil1999gmail.com.")


# Create your views here.
def index(request):
    customer_list=customer.objects.all()
    return render(request,'index.html',{'customer':customer_list})
