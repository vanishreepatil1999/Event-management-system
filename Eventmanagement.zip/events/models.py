from django.db import models

# Create your models here.


# Create your models here.
class customer(models.Model):
    name=models.CharField(max_length=100)
    event=models.CharField(max_length=100)
    picture=models.ImageField()
    email=models.CharField(max_length=100)
    description=models.TextField()

    def __str__(self):
        result=self.name+" by "+self.email
        return result
    class Meta:
        db_table="customers"